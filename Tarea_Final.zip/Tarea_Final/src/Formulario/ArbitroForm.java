package Formulario;
import clases.Arbitro;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Guillermo
 */
public class ArbitroForm extends javax.swing.JInternalFrame {

   EntityManagerFactory emf = null;
   EntityManager em = null;
   private int filaSeleccionada = -1;
   
    public ArbitroForm() {
                initComponents();
                emf = Persistence.createEntityManagerFactory("C:/base/tareafinal.odb");
                em = emf.createEntityManager();
                 listar();        
                 guardar.setVisible(true);
                 editar.setVisible(false);
                 borrar.setVisible(false);
                 cancelar.setVisible(false);
    }

public Arbitro crearArbitro() {
    String arbitro = NombreArbitro.getText();
    String edadTexto = Edad.getText();
    
    if (arbitro.isEmpty() || edadTexto.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Debes ingresar todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        return null; 
    }
    
    int edad;
    try {
        edad = Integer.parseInt(edadTexto);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "La edad debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
        return null;
    }
    
    Arbitro A = new Arbitro(arbitro, edad);
    return A;
}

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        NombreArbitro = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        guardar = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        borrar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Edad = new javax.swing.JTextField();
        cancelar = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Registrar Arbitros");

        jLabel1.setText("Registrar Arbitro");

        jLabel2.setText("Nombre:");

        NombreArbitro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreArbitroActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Edad"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        guardar.setText("GUARDAR");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });

        editar.setText("EDITAR");
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });

        borrar.setText("BORRAR");
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });

        jLabel3.setText("Listado de Arbitros");

        jLabel4.setText("Edad:");

        cancelar.setText("CANCELAR");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4))
                                .addGap(41, 41, 41))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(guardar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(editar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(borrar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cancelar)
                                .addGap(14, 14, 14))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(Edad, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NombreArbitro, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 443, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(NombreArbitro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Edad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(guardar)
                            .addComponent(editar)
                            .addComponent(borrar)
                            .addComponent(cancelar))))
                .addGap(99, 99, 99))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NombreArbitroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreArbitroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreArbitroActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        // TODO add your handling code here:
        em = emf.createEntityManager(); 
        Arbitro A = crearArbitro();
         if (A == null) {
        JOptionPane.showMessageDialog(null, "Debe ingresar Datos", "Advertencia", JOptionPane.INFORMATION_MESSAGE);
         }else{
        try {
            em.getTransaction().begin();
            em.persist(A);
            em.getTransaction().commit();
         JOptionPane.showMessageDialog(this, "Registro guardado correctamente", "Guardado exitoso", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
                    ex.printStackTrace();
        } finally {
                        em.close();
        }
         }
            listar();

           // Limpia los campos de texto
            NombreArbitro.setText("");
            Edad.setText("");
    }//GEN-LAST:event_guardarActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
                if (filaSeleccionada != -1) {
                    String nuevoArbitro = NombreArbitro.getText();
                    String edadTexto = Edad.getText();

                    int idArbitro = (int) tabla.getValueAt(filaSeleccionada, 0);

                    em = emf.createEntityManager();
                    
                        if (nuevoArbitro.isEmpty() || edadTexto.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Debes ingresar todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                    }else{
                    try {
                        int edad;
                        edad = Integer.parseInt(edadTexto);

                        em.getTransaction().begin();
                        Arbitro A = em.find(Arbitro.class, idArbitro);
                        A.setNombre(nuevoArbitro);
                        A.setEdad(edad);
                        em.getTransaction().commit();
                        JOptionPane.showMessageDialog(this, "Registro editado correctamente", "Edición exitosa", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        em.close();
                    }
                }
                
                    listar();
                    NombreArbitro.setText("");
                    Edad.setText("");
                    filaSeleccionada = -1;
                }
                 guardar.setVisible(true); 
                 editar.setVisible(false);
                 borrar.setVisible(false);
                 cancelar.setVisible(false);
    }//GEN-LAST:event_editarActionPerformed

    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarActionPerformed
        int idArbitro = (int) tabla.getValueAt(filaSeleccionada, 0);

        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Arbitro A = em.find(Arbitro.class, idArbitro);
            em.remove(A);
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(this, "Registro eliminado correctamente", "Eliminación exitosa", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            em.close();
        }

        listar();
        NombreArbitro.setText("");
        Edad.setText("");
        
                 guardar.setVisible(true); 
                 editar.setVisible(false);
                 borrar.setVisible(false);
                 cancelar.setVisible(false);
    }//GEN-LAST:event_borrarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        // TODO add your handling code here:
                       // Obtiene la fila seleccionada
            filaSeleccionada = tabla.getSelectedRow();

        // Verifica si se seleccionó una fila
        if (filaSeleccionada != -1) {
            // Obtiene los datos de la fila seleccionada
            String nombreSeleccionado = (String) tabla.getValueAt(filaSeleccionada, 1);
            Integer edadSeleccionada = (Integer) tabla.getValueAt(filaSeleccionada, 2);

            // Muestra los datos en los campos de texto
            NombreArbitro.setText(nombreSeleccionado);
           Edad.setText(edadSeleccionada.toString());

        }
                 guardar.setVisible(false); 
                 editar.setVisible(true);
                 borrar.setVisible(true);
                 cancelar.setVisible(true);
    }//GEN-LAST:event_tablaMouseClicked

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
                 listar();
                 NombreArbitro.setText("");
                 Edad.setText("");
                 guardar.setVisible(true); 
                 editar.setVisible(false);
                 borrar.setVisible(false);
                 cancelar.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

            public void listar() {
                em = emf.createEntityManager(); // Crear un nuevo EntityManager.
                try {
                    Query consulta = em.createQuery("SELECT G FROM Arbitro G");
                    List<Arbitro> resultados = consulta.getResultList();

                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.setRowCount(0);

                    for (Arbitro G : resultados) {
                        Object[] fila = new Object[3]; // Crear un arreglo de objetos para representar una fila en la tabla
                        fila[0] = G.getId(); // Agregar el ID como entero
                        fila[1] = G.getNombre();
                        fila[2] = G.getedad();
                        modelo.addRow(fila); // Agregar la fila al modelo de la tabla
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    em.close();
                }
        } 
 
        
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Edad;
    private javax.swing.JTextField NombreArbitro;
    private javax.swing.JButton borrar;
    private javax.swing.JButton cancelar;
    private javax.swing.JButton editar;
    private javax.swing.JButton guardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
