package Formulario;
import clases.Arbitro;
import clases.Equipo;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Guillermo
 */
public class EquipoForm extends javax.swing.JInternalFrame {

   EntityManagerFactory emf = null;
   EntityManager em = null;
   private int filaSeleccionada = -1;
   
    public EquipoForm() {
                initComponents();
                emf = Persistence.createEntityManagerFactory("C:/base/tareafinal.odb");
                em = emf.createEntityManager();
                listarm();   
                GUARDAR.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                CANCELAR.setVisible(false);
    }

     public Equipo crearEquipo(){   
        String nomEquipo = NombreEquipo.getText();
        String Estadio = estadio.getText();
        
         if (nomEquipo.isEmpty() || Estadio.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Debes ingresar todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        return null; 
         }
        Equipo A = new Equipo(nomEquipo, Estadio);
   
        return A;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        NombreEquipo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        GUARDAR = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        borrar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        estadio = new javax.swing.JTextField();
        CANCELAR = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jLabel1.setText("Formulario de Equipos");

        jLabel2.setText("Nombre del equipo:");

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Estadio"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        GUARDAR.setText("GUARDAR");
        GUARDAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GUARDARActionPerformed(evt);
            }
        });

        editar.setText("EDITAR");
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });

        borrar.setText("BORRAR");
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });

        jLabel4.setText("Estadio:");

        CANCELAR.setText("CANCELAR");
        CANCELAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CANCELARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(GUARDAR)
                        .addGap(18, 18, 18)
                        .addComponent(editar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(borrar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(NombreEquipo, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                            .addComponent(estadio))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(CANCELAR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(NombreEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(estadio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(79, 79, 79)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(GUARDAR)
                            .addComponent(editar)
                            .addComponent(borrar)
                            .addComponent(CANCELAR)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void GUARDARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GUARDARActionPerformed
        // TODO add your handling code here:
        em = emf.createEntityManager(); 
        Equipo E = crearEquipo();
        
         if (E == null) {
        JOptionPane.showMessageDialog(null, "Debe ingresar Datos", "Advertencia", JOptionPane.INFORMATION_MESSAGE);
         }else{
        try {
            em.getTransaction().begin();
            em.persist(E);
            em.getTransaction().commit();
         JOptionPane.showMessageDialog(this, "Registro guardado correctamente", "Guardado exitoso", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
                    ex.printStackTrace();
        } finally {
                        em.close();
        }
        }
            listarm();

           // Limpia los campos de texto
            NombreEquipo.setText("");
            estadio.setText("");
                GUARDAR.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                CANCELAR.setVisible(false);
    }//GEN-LAST:event_GUARDARActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
                if (filaSeleccionada != -1) {
                    String nuevoEquipo = NombreEquipo.getText();
                    String nuevoEstadio = estadio.getText();
                    int id = (int) tabla.getValueAt(filaSeleccionada, 0);
                    
                        if (nuevoEquipo.isEmpty() || nuevoEstadio.isEmpty()) {
                       JOptionPane.showMessageDialog(null, "Debes ingresar todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                        }else{
                        
                    em = emf.createEntityManager();
                    try {
                        em.getTransaction().begin();
                        Equipo E = em.find(Equipo.class, id);
                        E.setNombre(nuevoEquipo);
                        E.setEstadio(nuevoEstadio);
                        em.getTransaction().commit();
                        JOptionPane.showMessageDialog(this, "Registro editado correctamente", "Edición exitosa", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        em.close();
                    }
                        }
                    listarm();
                    NombreEquipo.setText("");
                    estadio.setText("");
                    filaSeleccionada = -1;
                }
                GUARDAR.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                CANCELAR.setVisible(false);
    }//GEN-LAST:event_editarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
                       // Obtiene la fila seleccionada
            filaSeleccionada = tabla.getSelectedRow();
                GUARDAR.setVisible(false);
                editar.setVisible(true);
                borrar.setVisible(true);
                CANCELAR.setVisible(true);
        // Verifica si se seleccionó una fila
        if (filaSeleccionada != -1){ 
            // Obtiene los datos de la fila seleccionada
            String nombreSeleccionado = (String) tabla.getValueAt(filaSeleccionada, 1);
            String estadioSeleccionadio = (String) tabla.getValueAt(filaSeleccionada, 2);
            // Muestra los datos en los campos de texto
            NombreEquipo.setText(nombreSeleccionado);
            estadio.setText(estadioSeleccionadio);
        }    }//GEN-LAST:event_tablaMouseClicked

    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarActionPerformed
        int idEquipo = (int) tabla.getValueAt(filaSeleccionada, 0);

        em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Equipo A = em.find(Equipo.class, idEquipo);
            em.remove(A);
            em.getTransaction().commit();
            JOptionPane.showMessageDialog(this, "Registro eliminado correctamente", "Eliminación exitosa", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            em.close();
        }

        listarm();
        NombreEquipo.setText("");
       estadio.setText("");
       
                GUARDAR.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                CANCELAR.setVisible(false);
     }//GEN-LAST:event_borrarActionPerformed

    private void CANCELARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CANCELARActionPerformed
            NombreEquipo.setText("");
            estadio.setText("");
                GUARDAR.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                CANCELAR.setVisible(false);
    }//GEN-LAST:event_CANCELARActionPerformed

            public void listarm() {
                em = emf.createEntityManager(); // Crear un nuevo EntityManager.
                try {
                    Query consulta = em.createQuery("SELECT E FROM Equipo E");
                    List<Equipo> resultados = consulta.getResultList();

                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.setRowCount(0);

                    for (Equipo E : resultados) {
                        Object[] fila = new Object[3]; // Crear un arreglo de objetos para representar una fila en la tabla
                        fila[0] = E.getId(); // Agregar el ID como entero
                        fila[1] = E.getNombre();
                        fila[2] = E.getEstadio();
                        modelo.addRow(fila); // Agregar la fila al modelo de la tabla
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    em.close();
                }
        } 
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CANCELAR;
    private javax.swing.JButton GUARDAR;
    private javax.swing.JTextField NombreEquipo;
    private javax.swing.JButton borrar;
    private javax.swing.JButton editar;
    private javax.swing.JTextField estadio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
