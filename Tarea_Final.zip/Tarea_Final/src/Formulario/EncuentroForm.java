/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Formulario;
import Clases.Encuentro;
import clases.Arbitro;
import clases.Equipo;
import javax.swing.JOptionPane;
import javax.swing.DefaultComboBoxModel;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Guillermo
 */
public class EncuentroForm extends javax.swing.JInternalFrame {

    /**
     * Creates new form EncuentroForm
     */
        EntityManagerFactory emf = null;
        EntityManager em = null;
        
        private int filaSeleccionada = -1;

            public EncuentroForm() {
                initComponents();
                emf = Persistence.createEntityManagerFactory("C:/base/tareafinal.odb");
                em = emf.createEntityManager();
                listar();
                cargarArbitro();
                cargarEquipo();
                cargarEquipoB();
                filtrarCampeonato();
                guardar.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                cancelar.setVisible(false);
            }  

   public Encuentro crearEncuentro() {
    String nombrecamp = nombreCampeonato.getText();
    String rondaE = ronda.getText(); 
    String arbitro = (String) ComboArbitro.getSelectedItem();
    String equipoa = (String) comboEquipoA.getSelectedItem();
    String equipob = (String) comboEquipoB.getSelectedItem();
    String marcadorE = marcador.getText();
 
    if (nombrecamp.isEmpty() || rondaE.isEmpty() || arbitro == null || equipoa == null || equipob == null || marcadorE.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Debes ingresar todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
        return null; 
    }else{
    
    Encuentro E = new Encuentro(nombrecamp, rondaE,  equipoa, equipob, arbitro, marcadorE);
    return E;
    }
}

public void listar() {
                em = emf.createEntityManager(); // Crear un nuevo EntityManager.
                try {
                    Query consultaGen = em.createQuery("SELECT E FROM Encuentro E");
                    List<Encuentro> resultados = consultaGen.getResultList();

                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.setRowCount(0);

                    for (Encuentro E : resultados) {
                        Object[] fila = new Object[7]; // Crear un arreglo de objetos para representar una fila en la tabla
                        fila[0] = E.getid();
                        fila[1] = E.getNombreCampeonato();
                        fila[2] = E.getRonda();
                        fila[3] = E.getEquipoA();
                        fila[4] = E.getEquipoB();
                        fila[5] = E.getArbitro();
                        fila[6] = E.getMarcador();
                        modelo.addRow(fila); // Agregar la fila al modelo de la tabla
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    em.close();
                }
        } 
private void cargarEquipo() {
    em = emf.createEntityManager(); // Crear un nuevo EntityManager.

    try {
        Query consultaGeneros = em.createQuery("SELECT G FROM Equipo G");
        List<Equipo> resultadosEquipo = consultaGeneros.getResultList();

        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();

        for (Equipo equipo : resultadosEquipo) {
            modelo.addElement(equipo.getNombre());
        }

        comboEquipoA.setModel(modelo); // Establecer el modelo del combo box actualizado
    } catch (Exception ex) {
        ex.printStackTrace();
    } finally {
        em.close();
    }
}
private void cargarEquipoB() {
    em = emf.createEntityManager(); // Crear un nuevo EntityManager.

    try {
        Query consultaGeneros = em.createQuery("SELECT G FROM Equipo G");
        List<Equipo> resultadosEquipo = consultaGeneros.getResultList();

        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();

        for (Equipo equipo : resultadosEquipo) {
            modelo.addElement(equipo.getNombre());
        }

        comboEquipoB.setModel(modelo); // Establecer el modelo del combo box actualizado
    } catch (Exception ex) {
        ex.printStackTrace();
    } finally {
        em.close();
    }
}
private void cargarArbitro() {
    em = emf.createEntityManager(); 

    try {
        Query consultaGeneros = em.createQuery("SELECT G FROM Arbitro G");
        List<Arbitro> resultadosArbitro = consultaGeneros.getResultList();

        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();

        for (Arbitro arbitro : resultadosArbitro) {
            modelo.addElement(arbitro.getNombre());
        }

        ComboArbitro.setModel(modelo);
    } catch (Exception ex) {
        ex.printStackTrace();
    } finally {
        em.close();
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        nombreCampeonato = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        ronda = new javax.swing.JTextField();
        comboEquipoA = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        comboEquipoB = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        marcador = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        ComboArbitro = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        guardar = new javax.swing.JButton();
        editar = new javax.swing.JButton();
        borrar = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        comboequipo = new javax.swing.JComboBox<>();
        buscar = new javax.swing.JButton();
        ListTodo = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        jLabel1.setText("Formulario de Registro de Encuentros de Futbol");

        jLabel2.setText("Campeonato:");

        jLabel3.setText("Ronda:");

        comboEquipoA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setText("Equipo Local:");

        jLabel5.setText("Equipo Visitante:");

        comboEquipoB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboEquipoB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboEquipoBActionPerformed(evt);
            }
        });

        jLabel6.setText("Marcador:");

        jLabel7.setText("Arbitro:");

        ComboArbitro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboArbitro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboArbitroActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Campeonato", "Ronda", "Local", "Visitante", "Arbitro", "Marcador"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        jLabel8.setText("Listado de Encuentros:");

        guardar.setText("GUARDAR");
        guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarActionPerformed(evt);
            }
        });

        editar.setText("EDITAR");
        editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarActionPerformed(evt);
            }
        });

        borrar.setText("BORRAR");
        borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarActionPerformed(evt);
            }
        });

        cancelar.setText("CANCELAR");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        jLabel9.setText("Filtrar por:");

        comboequipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        buscar.setText("BUSCAR");
        buscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buscarMouseClicked(evt);
            }
        });

        ListTodo.setText("LISTAR TODO");
        ListTodo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ListTodoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(61, 61, 61))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel6))
                                        .addGap(18, 18, 18)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(marcador)
                                    .addComponent(ComboArbitro, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(comboEquipoB, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))
                                .addGap(33, 33, 33)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboEquipoA, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ronda)
                                    .addComponent(nombreCampeonato)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(46, 46, 46))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(guardar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editar)
                        .addGap(18, 18, 18)
                        .addComponent(borrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(comboequipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(buscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ListTodo)
                        .addGap(30, 30, 30))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 494, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(comboequipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscar)
                    .addComponent(ListTodo))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(nombreCampeonato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(ronda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboEquipoA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(comboEquipoB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ComboArbitro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(marcador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(guardar)
                            .addComponent(editar)
                            .addComponent(borrar)
                            .addComponent(cancelar)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboEquipoBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboEquipoBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboEquipoBActionPerformed

    private void ComboArbitroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboArbitroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboArbitroActionPerformed

    private void guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarActionPerformed
        // TODO add your handling code here:
        em = emf.createEntityManager(); 
        Encuentro  A = crearEncuentro();
        
     if (A == null) {
        JOptionPane.showMessageDialog(null, "Debe ingresar Datos", "Advertencia", JOptionPane.INFORMATION_MESSAGE);
    }else{       

        try {
            em.getTransaction().begin();
            em.persist(A);
            em.getTransaction().commit();
         JOptionPane.showMessageDialog(this, "Registro guardado correctamente", "Guardado exitoso", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
                    ex.printStackTrace();
        } finally {
                        em.close();
        }
        }
            listar();

           // Limpia los campos de texto
            nombreCampeonato.setText("");
            ronda.setText("");
            marcador.setText("");
            guardar.setVisible(true);
            editar.setVisible(false);
            borrar.setVisible(false);
            cancelar.setVisible(false);
    }//GEN-LAST:event_guardarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
            // Obtiene la fila seleccionada
            filaSeleccionada = tabla.getSelectedRow();

        // Verifica si se seleccionó una fila
        if (filaSeleccionada != -1) {
            // Obtiene los datos de la fila seleccionada
            String CampeonatoSeleccionado = (String) tabla.getValueAt(filaSeleccionada, 1);
            String rondaSeleccionado = (String) tabla.getValueAt(filaSeleccionada, 2);
            String equipoaseleccionado = (String) tabla.getValueAt(filaSeleccionada, 3);
            String equipobseleccionado = (String) tabla.getValueAt(filaSeleccionada, 4);
            String arbitroseleccionado = (String) tabla.getValueAt(filaSeleccionada, 5);
            String marcadorSeleccionado = (String) tabla.getValueAt(filaSeleccionada, 6);

            
            
            // Muestra los datos en los campos de texto
            nombreCampeonato.setText(CampeonatoSeleccionado);
            ronda.setText(rondaSeleccionado);   
            comboEquipoA.setSelectedItem(equipoaseleccionado);
            comboEquipoB.setSelectedItem(equipobseleccionado);
            ComboArbitro.setSelectedItem(arbitroseleccionado);
            marcador.setText(marcadorSeleccionado);
            guardar.setVisible(false);
            editar.setVisible(true);
            borrar.setVisible(true);
            cancelar.setVisible(true);
        }
    }//GEN-LAST:event_tablaMouseClicked
    
    
    private void borrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarActionPerformed
                    int filaSeleccionada = tabla.getSelectedRow();
                     if (filaSeleccionada != -1) {
                         int id_encuentro = (int) tabla.getValueAt(filaSeleccionada, 0);

                         em = emf.createEntityManager();
                         try {
                             em.getTransaction().begin();
                             Encuentro E = em.find(Encuentro.class, id_encuentro);
                             em.remove(E);
                             em.getTransaction().commit();
                             JOptionPane.showMessageDialog(this, "Encuentro eliminado correctamente", "Eliminación exitosa", JOptionPane.INFORMATION_MESSAGE);
                         } catch (Exception ex) {
                             ex.printStackTrace();
                         } finally {
                             em.close();
                         }

                            listar();
                            nombreCampeonato.setText("");
                            ronda.setText("");
                            marcador.setText("");
                            guardar.setVisible(true);
                            editar.setVisible(false);
                            borrar.setVisible(false);
                            cancelar.setVisible(false);
                             
                     }
    }//GEN-LAST:event_borrarActionPerformed

    private void editarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarActionPerformed
                if (filaSeleccionada != -1) {
                   String nuevoCampeonato = nombreCampeonato.getText();
                   String rondanueva = ronda.getText();
                   String nuevoequipoa = (String) comboEquipoA.getSelectedItem();
                   String nuevoequipob = (String) comboEquipoB.getSelectedItem();
                   String nuevoarbitro = (String) ComboArbitro.getSelectedItem();
                   String nuevomarcadorE = marcador.getText();
                   int id_encuentro = (int) tabla.getValueAt(filaSeleccionada, 0);

                    em = emf.createEntityManager();
                    
                    if (nuevoCampeonato.isEmpty() || rondanueva.isEmpty() || nuevoequipoa == null || nuevoequipob == null || nuevoarbitro == null || nuevomarcadorE.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Debes ingresar todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                    }else{
                    try {
                        em.getTransaction().begin();
                        Encuentro E = em.find(Encuentro.class, id_encuentro);
                        E.setNombreCampeonato(nuevoCampeonato);
                        E.setRonda(rondanueva);
                        E.setEquipoA(nuevoequipoa);
                        E.setEquipoB(nuevoequipob);
                        E.setArbitro(nuevoarbitro);
                        E.setmarcador(nuevomarcadorE);
                        em.getTransaction().commit();
                        JOptionPane.showMessageDialog(this, "Registro editado correctamente", "Edición exitosa", JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        em.close();
                    }
                }
                    listar();
                    nombreCampeonato.setText("");
                    ronda.setText("");
                    marcador.setText("");
                    filaSeleccionada = -1;
                }
                guardar.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                cancelar.setVisible(false);
    }//GEN-LAST:event_editarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
                nombreCampeonato.setText("");
                ronda.setText("");
                marcador.setText("");
                guardar.setVisible(true);
                editar.setVisible(false);
                borrar.setVisible(false);
                cancelar.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    private void buscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buscarMouseClicked
                
            String equipoSeleccionado = (String) comboequipo.getSelectedItem();

        em = emf.createEntityManager(); // Crear un nuevo EntityManager.
                try {
                    Query consulta = em.createQuery("SELECT E FROM Encuentro E WHERE E.equipoA = :equipoSeleccionado");
                    consulta.setParameter("equipoSeleccionado", equipoSeleccionado);
                    List<Encuentro> resultados = consulta.getResultList();

                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.setRowCount(0);

                    for (Encuentro E : resultados) {
                        Object[] fila = new Object[7]; // Crear un arreglo de objetos para representar una fila en la tabla
                        fila[0] = E.getid();
                        fila[1] = E.getNombreCampeonato();
                        fila[2] = E.getRonda();
                        fila[3] = E.getEquipoA();
                        fila[4] = E.getEquipoB();
                        fila[5] = E.getArbitro();
                        fila[6] = E.getMarcador();
                        modelo.addRow(fila); // Agregar la fila al modelo de la tabla
                    }

                    tabla.setModel(modelo); // Establecer el modelo de tabla actualizado
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    em.close();
                }
    }//GEN-LAST:event_buscarMouseClicked

    private void ListTodoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ListTodoMouseClicked
                em = emf.createEntityManager(); // Crear un nuevo EntityManager.
                try {
                    Query consultaGen = em.createQuery("SELECT E FROM Encuentro E");
                    List<Encuentro> resultados = consultaGen.getResultList();

                    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
                    modelo.setRowCount(0);

                    for (Encuentro E : resultados) {
                        Object[] fila = new Object[7]; // Crear un arreglo de objetos para representar una fila en la tabla
                        fila[0] = E.getid();
                        fila[1] = E.getNombreCampeonato();
                        fila[2] = E.getRonda();
                        fila[3] = E.getEquipoA();
                        fila[4] = E.getEquipoB();
                        fila[5] = E.getArbitro();
                        fila[6] = E.getMarcador();
                        modelo.addRow(fila); // Agregar la fila al modelo de la tabla
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                } finally {
                    em.close();
                }
    }//GEN-LAST:event_ListTodoMouseClicked
private void filtrarCampeonato() {
    em = emf.createEntityManager(); // Crear un nuevo EntityManager.

    try {
        Query consulta = em.createQuery("SELECT G FROM Equipo G");
        List<Equipo> resultados = consulta.getResultList();

        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();

        for (Equipo campeonato : resultados) {
            modelo.addElement(campeonato.getNombre());
        }

        comboequipo.setModel(modelo); // Establecer el modelo del combo box actualizado
    } catch (Exception ex) {
        ex.printStackTrace();
    } finally {
        em.close();
    }
    listar();
}  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboArbitro;
    private javax.swing.JButton ListTodo;
    private javax.swing.JButton borrar;
    private javax.swing.JButton buscar;
    private javax.swing.JButton cancelar;
    private javax.swing.JComboBox<String> comboEquipoA;
    private javax.swing.JComboBox<String> comboEquipoB;
    private javax.swing.JComboBox<String> comboequipo;
    private javax.swing.JButton editar;
    private javax.swing.JButton guardar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField marcador;
    private javax.swing.JTextField nombreCampeonato;
    private javax.swing.JTextField ronda;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
