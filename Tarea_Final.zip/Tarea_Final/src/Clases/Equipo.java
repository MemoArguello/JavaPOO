package clases;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Equipo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idEquipo;
    private String nombreEquipo;
    private String estadio;
      @OneToMany (mappedBy = "equipoA") Set<Equipo> equipo;  
      @OneToMany (mappedBy = "equipoB") Set<Equipo> equipob;  

    
    public Equipo() {
    }

    public Equipo(String nombre, String estadio) {
        this.nombreEquipo = nombre;
        this.estadio = estadio;
    }

    public int getId() {
        return idEquipo;
    }

    public String getNombre() {
        return nombreEquipo;
    }

     
    public void setNombre(String nombre) {
        this.nombreEquipo = nombre;
    }

public String getEstadio() {
        return estadio;
    }

     
    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }
}