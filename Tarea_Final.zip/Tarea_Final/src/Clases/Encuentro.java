package Clases;
import java.io.Serializable;
import javax.persistence.ManyToOne;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Entity;

/**
 *
 * @author Guillermo
 */
@Entity
public class Encuentro implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String NombreCampeonato;
    private String Ronda;
    private String marcador;
   @ManyToOne private String equipoA;
   @ManyToOne private String equipoB;
   @ManyToOne private String arbitro;

    public Encuentro(){
    }
    
    public Encuentro(String NombreCampeonato, String Ronda,  String equipoA, String equipoB, String arbitro, String marcador){
        this.NombreCampeonato = NombreCampeonato;
        this.Ronda = Ronda;
        this.equipoA = equipoA;
        this.equipoB = equipoB;
        this.arbitro = arbitro;
        this.marcador = marcador;

    }
    
    /*Getters y Setters*/
    public int getid() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombreCampeonato(){
            return NombreCampeonato;
    }
    
    public void  setNombreCampeonato(String nombrecampeonato){
        this.NombreCampeonato = nombrecampeonato;
    }
   
    public String getRonda(){
            return Ronda;
    }
    
    public void  setRonda(String ronda){
        this.Ronda = ronda;
    }
    
    public String getMarcador(){
        return marcador;
    }
    
    public void setmarcador(String marcador) {
        this.marcador = marcador;
    }
    
    public String getArbitro(){
        return arbitro;
    }
    
    public void setArbitro(String arbitro) {
        this.arbitro = arbitro;
    }
  
    public String getEquipoA(){
        return equipoA;
    }
    
    public void setEquipoA(String equipoa) {
        this.equipoA = equipoa;
    }

    public String getEquipoB(){
        return equipoB;
    }
    
    public void setEquipoB(String equipoB) {
        this.equipoB = equipoB;
    }
}
