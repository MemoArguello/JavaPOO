package clases;

import java.util.List;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity
public class Arbitro implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idArbitro;
    private String nombre;
    private int edad;
    
   @OneToMany (mappedBy = "Arbitro") Set<Arbitro> arbitro;
    
    public Arbitro() {
    }

    public Arbitro(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public int getedad(){
        return edad;
    }
    
    public void setEdad(int Nedad){
        this.edad = Nedad;
    }
    
    public int getId() {
        return idArbitro;
    }

    public String getNombre() {
        return nombre;
    }

     
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
}